const body=document.getElementById("body");
const otpContainer=document.getElementById("otp-container");
const otpInputBoxList=document.getElementById("otp-input-box-list");
const OtpValidation=document.getElementById("otp-validation");
const btnswitch=document.getElementById("switch");

let dynamiccode;
let ourOtp="";
let optTime=15;
let timerId;

function changeTheme(){
    const isLight=body.classList.contains("light-bg");

    if(isLight){
        body.classList.remove("light-bg");
        body.classList.add("dark-bg");
        otpContainer.classList.remove("light-bg","light-box-shadow");
        otpContainer.classList.add("dark-bg","dark-box-shadow");
    }
    else{
        body.classList.remove("dark-bg");
        body.classList.add("light-bg");
        otpContainer.classList.remove("dark-bg","dark-box-shadow");
        otpContainer.classList.add("light-bg","light-box-shadow");
    }
}

function inputOTP(e){
    const currentElement=e.target;
    const currentValue= e.target.value;
    const nextChild=currentElement.nextElementSibling;

    if(isNaN(currentValue)){
        currentElement.value="";
        return;
    }
    if(nextChild){
        nextChild.focus();
    }
    ourOtp=ourOtp+currentValue;
}

function generateOTP(){
    return Math.floor(1000+Math.random()*9000);
}

function otpSuccess(){
    OtpValidation.classList.remove("fail");
    OtpValidation.classList.add("success");
    OtpValidation.innerText="OTP Matched Successfully";
}

function otpFail(){
    OtpValidation.classList.remove("success");
    OtpValidation.classList.add("fail");
    OtpValidation.innerText="OTP Does Not Matched";
}

function validateOtp(){
    return dynamiccode==Number(ourOtp);
}

function checkOTP(e){
    inputOTP(e);

    const result=validateOtp();

    if(result){
        otpSuccess();
    }
    else{
        otpFail();
    }
}

function displayOTP(){
     const generatedOtp=document.getElementById("generated-otp");
     dynamiccode=generateOTP();

     timerId=setInterval(()=>{
        if(optTime<1){
            dynamiccode=null;
            return clearInterval(timerId);
        }
        optTime=optTime-1;
        generatedOtp.innerHTML= `<div>Our otp code is ${dynamiccode}</div>
        <button class="btn" onclick="reset()">reset</button>
        <div>expires in ${optTime}s</div>`;
     },1000);
}

function reset(){
    const generatedOtp=document.getElementById("generated-otp");
    clearInterval(timerId);
    dynamiccode=null;
    ourOtp="";
    optTime=15;
    generatedOtp.innerHTML="Loading...";
    setTimeout(displayOTP,1000);
}

btnswitch.addEventListener("click",changeTheme);
otpInputBoxList.addEventListener("input",checkOTP);

setTimeout(displayOTP,1000);